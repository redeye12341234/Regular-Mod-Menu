using System.Windows;
using System.Windows.Controls;

namespace ModManager.Views;

public sealed class InputDialog : Window
{
    private readonly TextBox input = new()
    {
        MinWidth = 270,
        Margin = new Thickness(0, 12, 0, 12),
        Background = new System.Windows.Media.SolidColorBrush(
            System.Windows.Media.Color.FromRgb(25, 32, 48)),
        Foreground = System.Windows.Media.Brushes.White,
        BorderBrush = new System.Windows.Media.SolidColorBrush(
            System.Windows.Media.Color.FromRgb(71, 85, 105)),
        CaretBrush = System.Windows.Media.Brushes.White,
        SelectionBrush = new System.Windows.Media.SolidColorBrush(
            System.Windows.Media.Color.FromRgb(37, 99, 235))
    };
    public string Value => input.Text.Trim();

    private InputDialog(string title, string prompt, string initial)
    {
        Title = title;
        Width = 370;
        Height = 175;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        ResizeMode = ResizeMode.NoResize;
        Background = new System.Windows.Media.SolidColorBrush(
            System.Windows.Media.Color.FromRgb(15, 20, 32));
        Foreground = System.Windows.Media.Brushes.White;

        var panel = new StackPanel { Margin = new Thickness(18) };
        panel.Children.Add(new TextBlock
        {
            Text = prompt,
            Foreground = System.Windows.Media.Brushes.White
        });
        input.Text = initial;
        panel.Children.Add(input);

        var buttons = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right
        };

        buttons.Children.Add(new Button
        {
            Content = "Cancel",
            IsCancel = true,
            Background = new System.Windows.Media.SolidColorBrush(
                System.Windows.Media.Color.FromRgb(38, 50, 70)),
            Foreground = System.Windows.Media.Brushes.White,
            BorderBrush = System.Windows.Media.Brushes.Transparent,
            Padding = new Thickness(12, 5, 12, 5),
            Margin = new Thickness(0, 0, 8, 0)
        });

        var ok = new Button
        {
            Content = "Continue",
            IsDefault = true,
            Background = new System.Windows.Media.SolidColorBrush(
                System.Windows.Media.Color.FromRgb(37, 99, 235)),
            Foreground = System.Windows.Media.Brushes.White,
            BorderBrush = System.Windows.Media.Brushes.Transparent,
            Padding = new Thickness(12, 5, 12, 5)
        };
        ok.Click += (_, _) =>
        {
            if (!string.IsNullOrWhiteSpace(Value))
                DialogResult = true;
        };

        buttons.Children.Add(ok);
        panel.Children.Add(buttons);
        Content = panel;
    }

    public static string? Show(Window owner, string title, string prompt, string initial = "")
    {
        var d = new InputDialog(title, prompt, initial) { Owner = owner };
        return d.ShowDialog() == true ? d.Value : null;
    }
}
