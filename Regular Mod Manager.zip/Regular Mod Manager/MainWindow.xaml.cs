using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ModManager.Models;
using ModManager.Services;
using ModManager.Views;

namespace ModManager;

public partial class MainWindow : Window
{
    private readonly StorageService storage = new();
    private readonly ModService modService;
    private AppState state;
    private GameEntry? game;
    private ProfileEntry? profile;

    public MainWindow()
    {
        InitializeComponent();
        ProfilesList.PreviewMouseRightButtonUp += ProfilesList_PreviewMouseRightButtonUp;
        modService = new(storage);
        state = storage.Load();
        RefreshGames();
    }

    private void RefreshGames()
    {
        GamesList.ItemsSource = null;
        GamesList.ItemsSource = state.Games;
        EmptyHint.Visibility = state.Games.Count == 0
            ? Visibility.Visible : Visibility.Collapsed;
    }

    private void AddGame_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.OpenFolderDialog { Title = "Select the game's Mods folder" };
        if (dlg.ShowDialog(this) != true) return;
        AddGameFromFolder(dlg.FolderName);
    }

    private void AddGameFromFolder(string folder)
    {
        var defaultName = new DirectoryInfo(folder).Name;
        var name = InputDialog.Show(this, "Add game",
            "What should this game be called?", defaultName);
        if (string.IsNullOrWhiteSpace(name)) return;

        var item = new GameEntry { Name = name.Trim(), ModsPath = folder };
        item.Profiles.Add(new ProfileEntry());
        state.Games.Add(item);
        Save();
        RefreshGames();
    }

    private void OpenGame_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as FrameworkElement)?.Tag is not GameEntry selected) return;
        game = selected;

        if (game.Profiles.Count == 0)
            game.Profiles.Add(new ProfileEntry());

        GameTitle.Text = game.Name;
        GamePath.Text = game.ModsPath;
        ProfilesList.ItemsSource = null;
        ProfilesList.ItemsSource = game.Profiles;

        HomePanel.Visibility = Visibility.Collapsed;
        AddGameButton.Visibility = Visibility.Collapsed;
        GamePanel.Visibility = Visibility.Visible;
        ProfilesList.SelectedIndex = 0;
    }

    private void Back_Click(object sender, RoutedEventArgs e)
    {
        game = null;
        profile = null;
        GamePanel.Visibility = Visibility.Collapsed;
        HomePanel.Visibility = Visibility.Visible;
        AddGameButton.Visibility = Visibility.Visible;
        RefreshGames();
        Save();
    }

    private void ProfilesList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        profile = ProfilesList.SelectedItem as ProfileEntry;
        ModsList.ItemsSource = profile?.Mods;
    }

    private void NewProfile_Click(object sender, RoutedEventArgs e)
    {
        if (game is null) return;
        var name = InputDialog.Show(this, "New profile", "Profile name:");
        if (string.IsNullOrWhiteSpace(name)) return;

        var p = new ProfileEntry { Name = name };
        game.Profiles.Add(p);
        ProfilesList.Items.Refresh();
        ProfilesList.SelectedItem = p;
        Save();
    }

    private void RenameProfile_Click(object sender, RoutedEventArgs e)
    {
        if (profile is null) return;
        var name = InputDialog.Show(this, "Rename profile",
            "New profile name:", profile.Name);
        if (string.IsNullOrWhiteSpace(name)) return;

        profile.Name = name;
        ProfilesList.Items.Refresh();
        Save();
    }

    private void ProfilesList_PreviewMouseRightButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (e.OriginalSource is not DependencyObject source) return;

        var item = ItemsControl.ContainerFromElement(ProfilesList, source) as ListBoxItem;
        if (item?.DataContext is not ProfileEntry selectedProfile) return;

        ProfilesList.SelectedItem = selectedProfile;

        // Build the context menu in code to avoid WPF's generated XAML
        // connector wiring the MenuItem/ContextMenu to an unrelated Button.
        var contextMenu = new ContextMenu
        {
            Background = System.Windows.Media.Brushes.Black,
            Foreground = System.Windows.Media.Brushes.White,
            BorderBrush = new System.Windows.Media.SolidColorBrush(
                System.Windows.Media.Color.FromRgb(55, 65, 81))
        };
        var renameItem = new MenuItem { Header = "Rename profile" };
        renameItem.Click += (_, _) =>
        {
            ProfilesList.SelectedItem = selectedProfile;
            profile = selectedProfile;
            RenameProfile_Click(this, new RoutedEventArgs());
        };
        var deleteItem = new MenuItem { Header = "Delete profile" };
        deleteItem.Click += DeleteProfile_ContextMenuClick;
        contextMenu.Items.Add(renameItem);
        contextMenu.Items.Add(deleteItem);
        item.ContextMenu = contextMenu;
        contextMenu.PlacementTarget = item;
        contextMenu.IsOpen = true;
        e.Handled = true;
    }

    private void DeleteProfile_ContextMenuClick(object sender, RoutedEventArgs e)
    {
        if (sender is not MenuItem menuItem ||
            menuItem.Parent is not ContextMenu contextMenu ||
            contextMenu.PlacementTarget is not ListBoxItem listItem ||
            listItem.DataContext is not ProfileEntry selectedProfile ||
            game is null) return;

        profile = selectedProfile;
        if (MessageBox.Show($"Delete the profile '{selectedProfile.Name}' and its imported mod copies?",
            "Delete profile", MessageBoxButton.YesNo,
            MessageBoxImage.Warning) != MessageBoxResult.Yes) return;

        foreach (var mod in selectedProfile.Mods)
        {
            try { modService.DeleteImported(game.Id, mod); }
            catch (Exception ex) { Error(ex); }
        }

        game.Profiles.Remove(selectedProfile);
        profile = null;
        ProfilesList.Items.Refresh();
        ProfilesList.SelectedIndex = game.Profiles.Count > 0 ? 0 : -1;
        ModsList.ItemsSource = profile?.Mods;
        Save();
    }

    private void DeleteGame_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as FrameworkElement)?.Tag is not GameEntry selectedGame) return;

        if (MessageBox.Show(
            $"Remove '{selectedGame.Name}' from Mod Manager?\n\nThe game's actual Mods folder will NOT be changed. Its imported mod copies managed by this app will be deleted.",
            "Delete game", MessageBoxButton.YesNo,
            MessageBoxImage.Warning) != MessageBoxResult.Yes) return;

        foreach (var savedProfile in selectedGame.Profiles)
        {
            foreach (var mod in savedProfile.Mods)
            {
                try { modService.DeleteImported(selectedGame.Id, mod); }
                catch (Exception ex) { Error(ex); }
            }
        }

        state.Games.Remove(selectedGame);
        if (game?.Id == selectedGame.Id)
        {
            game = null;
            profile = null;
            GamePanel.Visibility = Visibility.Collapsed;
            HomePanel.Visibility = Visibility.Visible;
            AddGameButton.Visibility = Visibility.Visible;
        }
        Save();
        RefreshGames();
    }

    private void AddMod_Click(object sender, RoutedEventArgs e)
    {
        if (game is null || profile is null) return;

        var dlg = new Microsoft.Win32.OpenFolderDialog { Title = "Select a mod folder" };
        if (dlg.ShowDialog(this) != true) return;
        AddModFromFolder(dlg.FolderName);
    }

    private void AddModFromFolder(string folder)
    {
        if (game is null || profile is null) return;

        var defaultName = new DirectoryInfo(folder).Name;
        var name = InputDialog.Show(this, "Add mod", "Mod name:", defaultName);
        if (string.IsNullOrWhiteSpace(name)) return;

        try
        {
            profile.Mods.Add(modService.Import(game.Id, folder, name.Trim()));
            ModsList.Items.Refresh();
            Save();
        }
        catch (Exception ex) { Error(ex); }
    }

    private void FolderDragOver(object sender, DragEventArgs e)
    {
        e.Effects = GetDroppedFolders(e).Length > 0
            ? DragDropEffects.Copy : DragDropEffects.None;
        e.Handled = true;
    }

    private void Home_Drop(object sender, DragEventArgs e)
    {
        var folders = GetDroppedFolders(e);
        if (folders.Length == 0) return;
        e.Handled = true;

        // A dropped folder on the home screen is treated as a game's Mods folder.
        AddGameFromFolder(folders[0]);
    }

    private void Game_Drop(object sender, DragEventArgs e)
    {
        var folders = GetDroppedFolders(e);
        if (folders.Length == 0) return;
        e.Handled = true;

        // Import each dropped folder into the currently selected profile.
        foreach (var folder in folders)
            AddModFromFolder(folder);
    }

    private static string[] GetDroppedFolders(DragEventArgs e)
    {
        if (!e.Data.GetDataPresent(DataFormats.FileDrop))
            return [];

        return (e.Data.GetData(DataFormats.FileDrop) as string[] ?? [])
            .Where(Directory.Exists)
            .ToArray();
    }

    private void RemoveMod_Click(object sender, RoutedEventArgs e)
    {
        if (game is null || profile is null ||
            ModsList.SelectedItem is not ModEntry mod) return;

        try
        {
            modService.DeleteImported(game.Id, mod);
            profile.Mods.Remove(mod);
            ModsList.Items.Refresh();
            Save();
        }
        catch (Exception ex) { Error(ex); }
    }

    private void Activate_Click(object sender, RoutedEventArgs e)
    {
        if (game is null || profile is null) return;
        try
        {
            modService.Apply(game, profile.Mods);
            Save();
            MessageBox.Show("Profile activated.");
        }
        catch (Exception ex) { Error(ex); }
    }

    private void Vanilla_Click(object sender, RoutedEventArgs e)
    {
        if (game is null) return;

        if (MessageBox.Show("Replace the current Mods folder with an empty folder?",
            "Vanilla", MessageBoxButton.YesNo,
            MessageBoxImage.Warning) != MessageBoxResult.Yes) return;

        try
        {
            modService.Apply(game, []);
            Save();
            MessageBox.Show("Vanilla mode activated.");
        }
        catch (Exception ex) { Error(ex); }
    }

    private void Save() => storage.Save(state);

    private static void Error(Exception ex) =>
        MessageBox.Show(ex.Message, "Mod Manager",
            MessageBoxButton.OK, MessageBoxImage.Error);
}
