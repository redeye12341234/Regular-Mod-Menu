using System.IO;
using ModManager.Models;

namespace ModManager.Services;

public sealed class ModService(StorageService storage)
{
    public ModEntry Import(string gameId, string source, string name)
    {
        if (!Directory.Exists(source))
            throw new DirectoryNotFoundException(source);

        var dest = Path.Combine(storage.Library(gameId), Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(dest);
        CopyContents(source, dest);

        return new ModEntry { Name = name, StoragePath = dest };
    }

    public void DeleteImported(string gameId, ModEntry mod)
    {
        var root = Path.GetFullPath(storage.Library(gameId))
            + Path.DirectorySeparatorChar;
        var path = Path.GetFullPath(mod.StoragePath);

        if (!path.StartsWith(root, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("Mod is outside the managed library.");

        if (Directory.Exists(path))
            Directory.Delete(path, true);
    }

    public void Apply(GameEntry game, IEnumerable<ModEntry> mods)
    {
        var target = Path.GetFullPath(game.ModsPath);
        Validate(target);
        Directory.CreateDirectory(Path.GetDirectoryName(target)!);

        var parent = Path.GetDirectoryName(target)!;
        var stage = Path.Combine(parent, ".ModManager-stage-" + Guid.NewGuid().ToString("N"));
        var previous = Path.Combine(parent, ".ModManager-previous-" + Guid.NewGuid().ToString("N"));

        Directory.CreateDirectory(stage);

        try
        {
            foreach (var mod in mods)
            {
                if (!Directory.Exists(mod.StoragePath))
                    throw new DirectoryNotFoundException("Missing imported mod: " + mod.Name);

                // Each imported mod gets its own named directory in the game's Mods folder.
                var folderName = SafeFolderName(mod.Name);
                var modDestination = Path.Combine(stage, folderName);

                // Avoid silently merging two mods that have the same display name.
                if (Directory.Exists(modDestination))
                    modDestination += "-" + mod.Id[..Math.Min(6, mod.Id.Length)];

                Directory.CreateDirectory(modDestination);
                CopyContents(mod.StoragePath, modDestination);
            }

            if (Directory.Exists(target))
                Directory.Move(target, previous);

            try
            {
                Directory.Move(stage, target);
            }
            catch
            {
                if (Directory.Exists(target))
                    Directory.Delete(target, true);

                if (Directory.Exists(previous))
                    Directory.Move(previous, target);

                throw;
            }

            if (Directory.Exists(previous))
                Directory.Delete(previous, true);
        }
        finally
        {
            if (Directory.Exists(stage))
                Directory.Delete(stage, true);
        }
    }

    private static string SafeFolderName(string name)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var safe = new string(name.Select(c => invalid.Contains(c) ? '_' : c).ToArray()).Trim();
        if (string.IsNullOrWhiteSpace(safe) || safe is "." or "..")
            return "Mod";
        return safe;
    }

    private static void Validate(string path)
    {
        if (!Path.IsPathFullyQualified(path) ||
            string.Equals(path.TrimEnd('\\'),
                Path.GetPathRoot(path)!.TrimEnd('\\'),
                StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                "Choose a valid Mods folder, not a drive root.");
        }
    }

    private static void CopyContents(string source, string dest)
    {
        Directory.CreateDirectory(dest);

        foreach (var file in Directory.EnumerateFiles(source))
            File.Copy(file, Path.Combine(dest, Path.GetFileName(file)), true);

        foreach (var dir in Directory.EnumerateDirectories(source))
        {
            var info = new DirectoryInfo(dir);

            if ((info.Attributes & FileAttributes.ReparsePoint) != 0)
                continue;

            CopyContents(dir, Path.Combine(dest, info.Name));
        }
    }
}
