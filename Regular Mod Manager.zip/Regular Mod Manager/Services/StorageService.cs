using System.IO;
using System.Text.Json;
using ModManager.Models;

namespace ModManager.Services;

public sealed class StorageService
{
    private readonly string root = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "ModManager");

    private string StateFile => Path.Combine(root, "state.json");

    public StorageService() => Directory.CreateDirectory(root);

    public AppState Load()
    {
        if (!File.Exists(StateFile)) return new();
        try
        {
            return JsonSerializer.Deserialize<AppState>(File.ReadAllText(StateFile)) ?? new();
        }
        catch { return new(); }
    }

    public void Save(AppState state)
    {
        Directory.CreateDirectory(root);
        var tmp = StateFile + ".tmp";
        File.WriteAllText(tmp, JsonSerializer.Serialize(state,
            new JsonSerializerOptions { WriteIndented = true }));
        File.Move(tmp, StateFile, true);
    }

    public string Library(string id) => Path.Combine(root, "Library", id);
}
