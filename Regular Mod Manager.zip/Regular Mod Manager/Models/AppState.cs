﻿namespace ModManager.Models;
public sealed class AppState
{
    public List<GameEntry> Games { get; set; } = [];
}
