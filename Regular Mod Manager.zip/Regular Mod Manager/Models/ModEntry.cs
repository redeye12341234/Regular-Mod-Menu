﻿namespace ModManager.Models;
public sealed class ModEntry
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Mod";
    public string StoragePath { get; set; } = "";
}
