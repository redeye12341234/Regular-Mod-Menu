﻿namespace ModManager.Models;
public sealed class ProfileEntry
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Default";
    public List<ModEntry> Mods { get; set; } = [];
}
