namespace ModManager.Models;
public sealed class GameEntry
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "Game";
    public string ModsPath { get; set; } = "";
    public List<ProfileEntry> Profiles { get; set; } = [];
}
