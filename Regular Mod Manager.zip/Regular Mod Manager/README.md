# Regular Mod Manager

A Windows WPF mod manager built for .NET 10.

## Run the application

1. Extract the `Regular Mod Manager.zip` archive.
2. Open PowerShell in the extracted `Regular Mod Manager` folder.
3. Make sure the .NET 10 SDK is installed.
4. Run:

```powershell
dotnet restore
dotnet build -c Release
dotnet run -c Release
```

## Create the standalone EXE

Run this in the same folder:

```powershell
dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
```

The executable will be named **Regular Mod Manager.exe** and will be located at:

`bin\Release\net10.0-windows\win-x64\publish\Regular Mod Manager.exe`

## Features

- Add games by selecting their Mods folder or dragging the folder onto the home screen.
- Import mods by selecting folders or dragging folders into an open game screen.
- Imported mods keep their own named folder inside the game's Mods folder.
- Create, rename, and delete profiles (right-click a profile to delete it).
- Delete games from the home screen using the trash icon.
- Activate a profile or switch to Vanilla (an empty Mods folder).
- Dark interface.

## Important

Activating a profile or Vanilla replaces the contents of the selected game's Mods folder. Close the game first and keep your own backup if you need one. Deleting a game entry does not modify the game's actual Mods folder; it only removes the game from this app and deletes the app-managed imported mod copies.
